from django.contrib import admin

# Register your models here.
from restapp.models import restmodel
admin.site.register(restmodel)